import React from "react";
import "./landing.css";

const Landing = () => {
  return <div className="landing-container"></div>;
};

export default Landing;
