import React from "react";

const ErrorElement = () => {
  return <div>ErrorElement</div>;
};

export default ErrorElement;
