import React from "react";
import "./footer.css";

const Footer = () => {
  return (
    <div className="footer-container">
      &copy; 2024 Copyright User Management System{" "}
    </div>
  );
};

export default Footer;
